<nav>
    <h1 class="pojok">Satriyo's Restaurant</h1>
        <ul>
            <li>
                <a href="/home/index">Home</a>
            </li>
            <li>
                <a href="/subfitur/catheringMenu">Cathering</a>
            </li>
            <li>
                <a href="/subfitur/rating">Rating</a>
            </li>
            <li>
                About
            </li>
        </ul>
</nav>
